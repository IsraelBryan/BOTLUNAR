//Ferramentas
const { Client, Events, GatewayIntentBits, Collection, Guild, GuildMember } = require('discord.js');
const dotenv = require('dotenv');
const client = new Client({ intents: [GatewayIntentBits.Guilds] })
dotenv.config()
const { TOKEN } = process.env
const fs = require("node:fs");
const path = require("node:path");
const keep_alive = require("./keep_alive");
const config = require("./config.json");
client.commands = new Collection()
const { VRChat, Enums } = require('vrchat-api-library');

//VRCHAT
const { stdin, stdout } = require('process');
const readline = require('readline');
const vrchat_user = 'UMBFB'
const vrchat_pass = 'umbreon_game23'
const channel_id = '1007850093703069736'
const vrchat = new VRChat();


//Importações
const commandsPath = path.join(__dirname, "commands")
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith(".js"))
console.log(commandFiles)

for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file)
    const command = require(filePath)

    if ("data" in command && "execute" in command) {
        client.commands.set(command.data.name, command)
    } else {
        console.log(`Isso aqui ${filePath} esta com "data" ou "execute" bombado`)
    }
}

client.once(Events.ClientReady, c => {
    console.log(`Logado como ${c.user.tag}}`)
    console.log(`O bot entrou nos servidores: ${Guild.name}, (id: ${Guild.id}), com uma população de ${Guild.member}}`)
})


client.login(TOKEN);
client.login(config.token);

client.on(Events.InteractionCreate, async interaction => {
    if (interaction.isStringSelectMenu()) {
        const selected = interaction.values[0]
        if (selected == "nardoragon") {
            await interaction.reply("Model: https://vrchive.nomieze.com/item/?assetId=65b3c4a7ebf077debfd5d580 ")
        } else if (selected == "deira") {
            await interaction.reply("Model: https://vrchive.nomieze.com/item/?assetId=64f43d663a29375dd846903e ")
        } else if (selected == "rindo") {
            await interaction.reply("Model: https://vrchive.nomieze.com/redirect/?downloadId=64f43d673a29375dd8469582 ")
        } else if (selected == "karin") {
            await interaction.reply("Model: https://vrchive.nomieze.com/item/?assetId=64f43d673a29375dd84695db ")
        } else if (selected == "kikyo") {
            await interaction.reply("Model: https://vrchive.nomieze.com/item/?assetId=64f43d673a29375dd846951c")
        } else if (selected == "chibi_novabeast") {
            await interaction.reply("Model: https://vrchive.nomieze.com/item/?assetId=66917c84b844c675ff34ade8")
        } else if (selected == "mamehinata") {
            await interaction.reply("Model: empty!!!")
        } else if (selected == "hyenid") {
            await interaction.reply("Model: https://workupload.com/archive/KApnaXv56z")
        } else if (selected == "rexouium") {
            await interaction.reply("Model: https://drive.google.com/file/d/1fZWjUp_Q-p_G2yREGx0FPwqC_2U5-sbU/view")
        } else if (selected == "kuuta") {
            await interaction.reply("Model: https://vrchive.nomieze.com/item/?assetId=666b689d0a3ae09105656570")
        } else if (selected == "vyllith") {
            await interaction.reply("Model: https://vrchive.nomieze.com/item/?assetId=6669dd3d92a88ea3dca06b4d")
        } else if (selected == "wickerbeast") {
            await interaction.reply("Model: https://drive.google.com/file/d/1WJ6Gp1kkrMkSjJCWzIML1TZ1jJKu_tFO/view")
        } else if (selected == "deira_neo") {
            await interaction.reply("Model: https://vrchive.nomieze.com/item/?assetId=665cea4edf50facd45f6416b")
        } else if (selected == "povichi") {
            await interaction.reply("Model: https://vrmodels.store/avatars/11495-povichi-v2.html")
        } else if (selected == "fredina's club") {
            await interaction.reply("Model: https://drive.google.com/file/d/1qUzqQBWjFCAf4oMWExanZX23RqHs89Pf/view")
        } else if (selected == "ku") {
            await interaction.reply("https://vrchive.nomieze.com/item/?assetId=64f43d663a29375dd846903b")
        } else if (selected == "haida") {
            await interaction.reply("Model: https://vrchive.nomieze.com/item/?assetId=64f43d663a29375dd8469038")
        } else if (selected == "akky") {
            await interaction.reply("Model: https://vrchive.nomieze.com/item/?assetId=64f43d663a29375dd846903d")
        } else if (selected == "rin") {
            await interaction.reply("Model: https://vrchive.nomieze.com/item/?assetId=662fce3312eccf561e2049fc")
        }
    }
    if (!interaction.isChatInputCommand()) return
    const command = interaction.client.commands.get(interaction.commandName)
    if (!command) {
        console.error("Comandinho não foi achado eiiin")
        return
    }
    try {
        await command.execute(interaction)
    } catch (error) {
        console.error(error)
        await interaction.reply("Houve um errinho da nossa parte (vulgo UMB)")
    }

})